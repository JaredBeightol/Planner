/*
 * Jared Beightol
 * Started 8/30/2018
 * Purpose: a planner where you can enter, see, and cancel tasks- they will be displayed by date
 * I have designed and implemented this code myself
 */


/*
 * TODO:
 * 
 */

import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectInputStream;
import java.io.ObjectOutputStream;
import java.util.Scanner;

public class Planner {
  public static void main(String[] args) throws IOException, ClassNotFoundException{
    //Declare stuff here...
	//Number of current Tasks
	int taskAmount = 0;
    Scanner userInput = new Scanner(System.in);
    //The max number of tasks that can be held at once
    final int TASK_LIMIT = 50;
    //The user's choices are temporarily stored here
    int actionChoice;
    //for loop variables
    int i = 0;
    int j = 0;
    //Boolean that creates a program loop
    boolean repeat = true;
    
    //3 arrays
    //array that is 1-TASK_LIMIT
    int[] taskNum = new int[TASK_LIMIT];
    for (i = 0; i < TASK_LIMIT; i++) {
    	taskNum[i] = i + 1;
    }
    //array that stores the month and day and year that the assignment is due
    int[][] taskDate = new int [3][TASK_LIMIT];
    //array that stores the assignment name
    String[] taskName = new String[TASK_LIMIT];
    
    
    
   
	    //DESERIALIZE
	    FileInputStream f_in = new FileInputStream("taskDate.data");
	    ObjectInputStream obj_in = new ObjectInputStream (f_in);
	    taskDate = (int[][])obj_in.readObject();
	    
	    FileInputStream f_in1 = new FileInputStream("taskName.data");
	    ObjectInputStream obj_in1 = new ObjectInputStream (f_in1);
	    taskName = (String[])obj_in.readObject();
	    
	    FileInputStream f_in2 = new FileInputStream("taskAmount.data");
	    ObjectInputStream obj_in2 = new ObjectInputStream (f_in2);
	    taskAmount = (int)obj_in.readObject();
    
    
    
    
    
    
    //Program loop
    while (repeat) {
    	//Calls a method to sort the tasks
    	sortTasks(taskNum, taskDate, taskName, taskAmount);
	    //Introduction- text displayed when program begins 
	    System.out.println("Do you want to see your current tasks or enter a new one?\nType '1' for the current ones, '2' for a new one, '3' to remove a task"
	    		+ "or '4' to Save and Quit.");
	    
	    System.out.println("Number of Tasks:" + taskAmount);
	    System.out.print("Action Choice: ");
	    
	    //Take userInput scanner 
	    while(!userInput.hasNextInt()) {
	    	userInput.next();
	    	System.out.println("Input must correlate to one of the options above.\nPlease enter your choice again.");
	    }
	    actionChoice = userInput.nextInt();
	    
	    
	    //Takes the user on 2 different tracks depending on what choice they made above
	    if (actionChoice == 1){
	    	displayTasks(taskNum, taskDate, taskName, taskAmount); //calls method to display tasks	
	    }else if(actionChoice == 2){
	    	addTasks(taskNum, taskDate, taskName, taskAmount); //calls method to add tasks
	  	  //Increase the task amount int variable
	  	  taskAmount = taskAmount + 1;
	    }else if(actionChoice == 3){
	    	removeTasks(taskNum, taskDate, taskName, taskAmount);
	    	//Decrease the task amount int variable
	    	taskAmount = taskAmount - 1;
	    }else if (actionChoice == 4) {
	    	System.out.println("\nExiting Planner Application...");
	    	repeat = false;
    	}else {
	    	System.out.println("Input must correlate to one of the options above.\nPlease enter your choice again.");
	    }
    }
    userInput.close();
    
    
    
    //Resets the data to 0 or null in the arrays for when the program gets jacked up.
//    taskDate = null;
//    taskName = null;
//    taskAmount = 0;
    
    
    
    
  //SERIALIZE
    //Task Date
    FileOutputStream f_out = new FileOutputStream("taskDate.data");
    ObjectOutputStream obj_out = new ObjectOutputStream (f_out);
    obj_out.writeObject (taskDate);
    
    //Task Name
    FileOutputStream f_out1 = new FileOutputStream("taskName.data");
    ObjectOutputStream obj_out1 = new ObjectOutputStream (f_out1);
    obj_out.writeObject (taskName);
    
    //Task Amount
    FileOutputStream f_out2 = new FileOutputStream("taskAmount.data");
    ObjectOutputStream obj_out2 = new ObjectOutputStream (f_out2);
    obj_out.writeObject (taskAmount);
    
    
    
//    //Use to test the data after being serialized
//    for (i = 0; i < taskDate.length; i ++)
//    	for (j = 0; j < 3; j++)
//    		System.out.println(taskDate[j][i]);
    
    
    //informs user that the program is over
    System.out.println("\nProgram Closed. EXIT THE PROGRAM, or turn the POWER OFF");
    
  }
  
  
  
  //CALLED BY IF STATEMENT WHEN USER WANTS TASKS DISPLAYED
  public static void displayTasks(int[]taskNum, int[][] taskDate, String[]taskName, int taskAmount) {
	  //for loop variables
	  int i = 0;
	  System.out.println("\n\n");
	  System.out.printf("%-53s", "TASK NAME");
	  System.out.printf("%-10s","DATE DUE");
	  System.out.println("\n");
	  
	  
	  for (i = 0; i < taskAmount; i++) {
		  System.out.printf("%-3s", i + 1 + ":");
		  System.out.printf("%-50s", taskName[i]);
		  System.out.printf("%-10s", taskDate[0][i] +"/" + taskDate[1][i] + "/" + taskDate[2][i]);
		  System.out.print("\n");
	  }
	  System.out.println("\n");
  }
  
  
  
  //CALLED WHEN USER WANTS TO ADD ASSIGNMENTS
  public static void addTasks(int[]taskNum, int[][] taskDate, String[]taskName, int taskAmount) {
	  //Variables and stuff
	  Scanner addTask = new Scanner(System.in);
	  
	  
	  //Prompt User
	  System.out.print("Name of the new task: ");
	  //Adds the name to the task list.
	  taskName[taskAmount] = addTask.nextLine();
	  //Adds the due date to the list
	  System.out.print("Month it is due: ");
	  while(!addTask.hasNextInt()) {
	   	 addTask.next();
	     System.out.println("Input must be a number.\nPlease enter your choice again.");
	  }
	  taskDate[0][taskAmount] = addTask.nextInt();
	  System.out.print("Day: ");
	  while(!addTask.hasNextInt()) {
		  addTask.next();
		  System.out.println("Input must be a number.\nPlease enter your choice again.");
	  }
	  taskDate[1][taskAmount] = addTask.nextInt();
	  System.out.print("Year: ");
	  while(!addTask.hasNextInt()) {
		  addTask.next();
	      System.out.println("Input must be a number.\nPlease enter your choice again.");
	  }
	  taskDate[2][taskAmount] = addTask.nextInt();
			  	  
  }
  
//CALLED WHEN A USER WANTS TO DELETE A TASK
  public static void removeTasks(int[]taskNum, int[][] taskDate, String[]taskName, int taskAmount) {
	  Scanner removeTask = new Scanner(System.in);
	  int deleteTask;
	  //for loop variables 
	  int i = 0;
	  
	  if (taskAmount > 0) {
		  //prompt user
		  System.out.println("\n\n");
		  System.out.println("Which task would you like to remove?");
		  System.out.println("\n\n");
		  System.out.printf("%-53s", "TASK NAME");
		  System.out.printf("%-10s","DATE DUE");
		  System.out.println("\n");
		  //Prints out tasks to choose from
		  for (i = 0; i < taskAmount; i++) {
			  System.out.printf("%-3s", i + 1 + ":");
			  System.out.printf("%-50s", taskName[i]);
			  System.out.printf("%-10s", taskDate[0][i] +"/" + taskDate[1][i] + "/" + taskDate[2][i]);
			  System.out.print("\n");
		  }
		  
		  //take input on which task to delete
		  deleteTask = removeTask.nextInt();
		  taskDate[0][deleteTask - 1] = 0;
		  taskDate[1][deleteTask - 1] = 0;
		  taskDate[2][deleteTask - 1] = 0;
		  taskName[deleteTask - 1] = null;
	  }
  }
  
  
  
  //Sort Tasks By Date
  public static void sortTasks(int[]taskNum, int[][] taskDate, String[]taskName, int taskAmount) {
	  //for loop variables
	  int i = 0;
	  int j = 0;
	  //used to hold temporary values when sorting arrays
	  int temp1 = 0;
	  String temp2;
	  
	  	  
	  //removes 'null' instances after task is deleted
	  for (j = 0; j < taskAmount; j++) {
		  for (i = 0; i < taskAmount; i++) {
			  if (taskDate[2][i] == 0 && taskDate[0][i] == 0 && taskDate[1][i] == 0) {
				  temp1 = taskDate[2][i];     
				  taskDate[2][i] = taskDate[2][i + 1];
				  taskDate[2][i + 1] = temp1;
				  temp1 = taskDate[1][i];                       
				  taskDate[1][i] = taskDate[1][i + 1];
				  taskDate[1][i + 1] = temp1;
				  temp1 = taskDate[0][i];                       
				  taskDate[0][i] = taskDate[0][i + 1];
				  taskDate[0][i + 1] = temp1;
				  temp2 = taskName[i];                       
				  taskName[i] = taskName[i + 1];
				  taskName[i + 1] = temp2;
			  }
		  }
	  }
	  
	  
	  //First, sort by year
	  for (j = 0; j < taskAmount; j++) {
		  for (i = 0; i < taskAmount - 1; i++) {
			  if (taskDate[2][i] > taskDate[2][i + 1]) {
				  temp1 = taskDate[2][i];     
				  taskDate[2][i] = taskDate[2][i + 1];
				  taskDate[2][i + 1] = temp1;
				  temp1 = taskDate[1][i];                       
				  taskDate[1][i] = taskDate[1][i + 1];
				  taskDate[1][i + 1] = temp1;
				  temp1 = taskDate[0][i];                       
				  taskDate[0][i] = taskDate[0][i + 1];
				  taskDate[0][i + 1] = temp1;
				  temp2 = taskName[i];                       
				  taskName[i] = taskName[i + 1];
				  taskName[i + 1] = temp2;
			  }else if (taskDate[2][i] == taskDate[2][i + 1] && taskDate[0][i] > taskDate[0][i + 1]) {
				  temp1 = taskDate[1][i];                       
				  taskDate[1][i] = taskDate[1][i + 1];
				  taskDate[1][i + 1] = temp1;
				  temp1 = taskDate[0][i];                       
				  taskDate[0][i] = taskDate[0][i + 1];
				  taskDate[0][i + 1] = temp1;
				  temp2 = taskName[i];                       
				  taskName[i] = taskName[i + 1];
				  taskName[i + 1] = temp2;
			  }else if (taskDate[2][i] == taskDate[2][i + 1] && taskDate[0][i] == taskDate[0][i + 1] && taskDate[1][i] > taskDate[1][i + 1]) {
				  temp1 = taskDate[1][i];       
				  taskDate[1][i] = taskDate[1][i + 1];
				  taskDate[1][i + 1] = temp1;
				  temp2 = taskName[i];                       
				  taskName[i] = taskName[i + 1];
				  taskName[i + 1] = temp2;
			  }
		  }
	  }
  }
}